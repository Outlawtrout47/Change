CHANGE: HOW TO PUT THIS ONLINE (about 5 minutes)

What's in this folder
- index.html: the Change app itself
- manifest.webmanifest: tells phones and laptops this website can be installed
- sw.js: lets the app open even with no internet
- icon files: the app icon (the 4 .png files)

Keep all of these files together in one folder. Don't rename them.

STEP 1: Put it online (free)
1. Unzip this folder so you have a normal folder called "change".
2. Go to https://app.netlify.com/drop
3. Drag the whole "change" folder onto the page.
4. In a few seconds you get a link that starts with https://. That's your app.

STEP 2: Install it
- iPhone: open the link in Safari, tap the Share button, tap "Add to Home Screen".
- Android: open the link in Chrome, tap the menu (three dots), tap "Install app".
- Laptop (Chrome or Edge): open the link and click the install icon at the right end of the address bar.

THINGS TO KNOW
- "Build my week" (the AI part) does not work on this version yet. It needs a small server to talk to the AI, which is the next piece to build. Everything else in the app works.
- Saved info stays on the device it was entered on. It won't sync between phone and laptop until the account and database piece is added.
- Updating later: change "change-v1" to "change-v2" near the top of sw.js, then drag the folder onto Netlify again.
